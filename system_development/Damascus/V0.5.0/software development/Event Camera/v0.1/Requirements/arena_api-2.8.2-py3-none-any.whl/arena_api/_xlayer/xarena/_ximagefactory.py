# -----------------------------------------------------------------------------
# Copyright (c) 2025, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

from ctypes import byref

from arena_api._xlayer.xarena.arenac import harenac
from arena_api._xlayer.xarena.arenac_types import (ac_bayer_algorithm,
                                                   acBuffer, size_t, uint64_t, 
                                                   double)


class _xImagefactory():

    @staticmethod
    def xImageFactoryCreate(pdata, data_size, width, height, pixel_format):

        data_size = size_t(data_size)
        width = size_t(width)
        height = size_t(height)
        pixel_format = uint64_t(pixel_format)
        buffer = acBuffer(None)
        # AC_ERROR acImageFactoryCreate(
        #   uint8_t* pData,
        #   size_t dataSize,
        #   size_t width,
        #   size_t height,
        #   uint64_t pixelFormat,
        #   acBuffer* phDst)
        harenac.acImageFactoryCreate(
            pdata,  # will be interperted as uint8_t* correctly
            data_size,
            width,
            height,
            pixel_format,
            byref(buffer))

        return buffer.value
    
    @staticmethod
    def xImageFactoryCreateEmpty(data_size, width, height, pixel_format):

        data_size = size_t(data_size)
        width = size_t(width)
        height = size_t(height)
        pixel_format = uint64_t(pixel_format)
        buffer = acBuffer(None)
        # AC_ERROR acImageFactoryCreateEmpty(
        #   size_t dataSize,
        #   size_t width,
        #   size_t height,
        #   uint64_t pixelFormat,
        #   acBuffer* phDst)
        harenac.acImageFactoryCreateEmpty(
            data_size,
            width,
            height,
            pixel_format,
            byref(buffer))

        return buffer.value
    
    @staticmethod
    def xImageFactoryCreateCompressedImage(pdata, data_size, pixel_format):

        data_size = size_t(data_size)
        pixel_format = uint64_t(pixel_format)
        buffer = acBuffer(None)
        # AC_ERROR acImageFactoryCreateCompressedImage(
        #   size_t dataSize,
        #   uint64_t pixelFormat,
        #   acBuffer* phDst)
        harenac.acImageFactoryCreateCompressedImage(
            pdata,  # will be interperted as uint8_t* correctly
            data_size,
            pixel_format,
            byref(buffer))

        return buffer.value

    @staticmethod
    def xImageFactoryShallow(pdata, data_size, width, height, pixel_format):
        data_size = size_t(data_size)
        width = size_t(width)
        height = size_t(height)
        pixel_format = uint64_t(pixel_format)
        buffer = acBuffer(None)
        # AC_ERROR acImageFactoryShallow(
        #   uint8_t* pData,
        #   size_t dataSize,
        #   size_t width,
        #   size_t height,
        #   uint64_t pixelFormat,
        #   acBuffer* phDst)
        harenac.acImageFactoryShallow(
            pdata, # will be interperted as uint8_t* correctly
            data_size,
            width,
            height,
            pixel_format,
            byref(buffer))

        return buffer.value

    @staticmethod
    def xImageFactoryCopy(hsrc):

        src_buffer = acBuffer(hsrc)
        dst_buffer = acBuffer(None)
        # AC_ERROR acImageFactoryCopy(
        #   acBuffer hSrc,
        #   acBuffer* phDst)
        harenac.acImageFactoryCopy(
            src_buffer,
            byref(dst_buffer))

        return dst_buffer.value
    
    @staticmethod
    def xImageFactoryCopyCompressedImage(hsrc):

        src_buffer = acBuffer(hsrc)
        dst_buffer = acBuffer(None)
        # AC_ERROR acImageFactoryCopyCompressedImage(
        #   acBuffer hSrc,
        #   acBuffer* phDst)
        harenac.acImageFactoryCopyCompressedImage(
            src_buffer,
            byref(dst_buffer))

        return dst_buffer.value
    
    @staticmethod
    def xImageFactoryDecompressImage(hsrc):

        src_buffer = acBuffer(hsrc)
        dst_buffer = acBuffer(None)
        # AC_ERROR acImageFactoryDecompressImage(
        #   acBuffer hSrc,
        #   acBuffer* phDst)
        harenac.acImageFactoryDecompressImage(
            src_buffer,
            byref(dst_buffer))

        return dst_buffer.value

    @staticmethod
    def xImageFactoryDestroy(hbuffer):

        buffer = acBuffer(hbuffer)
        # AC_ERROR acImageFactoryDestroy(
        #   acBuffer hBuffer)
        harenac.acImageFactoryDestroy(
            buffer)
        
    @staticmethod
    def xImageFactoryDestroyCompressedImage(hbuffer):

        buffer = acBuffer(hbuffer)
        # AC_ERROR acImageFactoryDestroyCompressedImage(
        #   acBuffer hBuffer)
        harenac.acImageFactoryDestroyCompressedImage(
            buffer)

    @staticmethod
    def xImageFactoryConvert(hsrc_buffer, pixel_format):

        src_buffer = acBuffer(hsrc_buffer)
        pixel_format = uint64_t(pixel_format)
        dst_buffer = acBuffer(None)
        # AC_ERROR acImageFactoryConvert(
        #   acBuffer hSrc,
        #   uint64_t pixelFormat,
        #   acBuffer* phDst)
        harenac.acImageFactoryConvert(
            src_buffer,
            pixel_format,
            byref(dst_buffer))

        return dst_buffer.value

    @staticmethod
    def xImageFactoryConvertBayerAlgorithm(hsrc_buffer, pixel_format, bayer_algorithm):

        src_buffer = acBuffer(hsrc_buffer)
        pixel_format = uint64_t(pixel_format)
        bayer_algorithm = ac_bayer_algorithm(bayer_algorithm)
        dst_buffer = acBuffer(None)
        # AC_ERROR acImageFactoryConvertBayerAlgorithm(
        #   acBuffer hSrc,
        #   uint64_t pixelFormat,
        #   AC_BAYER_ALGORITHM bayerAlgo,
        #   acBuffer* phDst)
        harenac.acImageFactoryConvertBayerAlgorithm(
            src_buffer,
            pixel_format,
            bayer_algorithm,
            byref(dst_buffer))

        return dst_buffer.value

    @staticmethod
    def xImageFactorySelectBits(hsrc_buffer, num_bits, offset):
        src_buffer = acBuffer(hsrc_buffer)
        num_bits = size_t(num_bits)
        offset = int(offset)
        dst_buffer = acBuffer(None)
        # AC_ERROR acImageFactorySelectBits(
        #   acBuffer hSrc,
        #   size_t numBits,
        #   int offset,
        #   acBuffer* phDst)
        harenac.acImageFactorySelectBits(
            src_buffer,
            num_bits,
            offset,
            byref(dst_buffer))

        return dst_buffer.value

    @staticmethod
    def xImageFactorySelectBitsAndScale(hsrc_buffer, num_bits, offset):

        src_buffer = acBuffer(hsrc_buffer)
        num_bits = size_t(num_bits)
        offset = double(offset)
        dst_buffer = acBuffer(None)
        # AC_ERROR acImageFactorySelectBitsAndScale(
        #   acBuffer hSrc,
        #   size_t numBits,
        #   double offset,
        #   acBuffer* phDst)
        harenac.acImageFactorySelectBitsAndScale(
            src_buffer,
            num_bits,
            offset,
            byref(dst_buffer))

        return dst_buffer.value
    
    @staticmethod
    def xImageFactoryProcessSoftwareLUT(hsrc_buffer, plut, len):

        src_buffer = acBuffer(hsrc_buffer)
        len = size_t(len)
        dst_buffer = acBuffer(None)
        # AC_ERROR acImageFactoryProcessSoftwareLUT(
        #   acBuffer hSrc,
        #   uint8_t* pLUT,
        #   size_t len,
        #   acBuffer* phDst)
        harenac.acImageFactoryProcessSoftwareLUT(
            src_buffer,
            plut, # will be interperted as uint8_t* correctly
            len,
            byref(dst_buffer)
        )
        
        return dst_buffer.value
    
    @staticmethod
    def xImageFactoryDeinterleaveChannels(hsrc_buffer):

        src_buffer = acBuffer(hsrc_buffer)
        dst_buffer = acBuffer(None)
        # AC_ERROR acImageFactoryDeinterleaveChannels(
        #   acBuffer hSrc, 
        #   acBuffer* phDst)
        harenac.acImageFactoryDeinterleaveChannels(
            src_buffer,
            byref(dst_buffer)
        )
        
        return dst_buffer.value
    
    @staticmethod
    def xImageFactoryDeinterleaveChannelsShallow(hsrc_buffer, pdata, len):

        src_buffer = acBuffer(hsrc_buffer)
        len = size_t(len)
        dst_buffer = acBuffer(None)
        # AC_ERROR acImageFactoryDeinterleaveChannelsShallow(
        #   acBuffer hSrc, 
        #   uint8_t* pData, 
        #   size_t len, 
        #   acBuffer* phDst)
        harenac.acImageFactoryDeinterleaveChannelsShallow(
            src_buffer,
            pdata, # will be interperted as uint8_t* correctly
            len,
            byref(dst_buffer)
        )
        
        return dst_buffer.value
    
    @staticmethod
    def xImageFactoryDeinterleaveChannelsLen(hsrc_buffer):

        src_buffer = acBuffer(hsrc_buffer)
        len = size_t(0)
        # AC_ERROR acImageFactoryDeinterleaveChannelsLen(
        #   acBuffer hSrc,
        #   size_t* len)
        harenac.acImageFactoryDeinterleaveChannelsLen(
            src_buffer,
            byref(len)
        )
        
        return len.value

    @staticmethod
    def xImageFactoryNumChannels(hsrc_buffer):

        src_buffer = acBuffer(hsrc_buffer)

        # get the number of buffers
        num_buffers = size_t(0)
        harenac.acImageFactorySplitChannels(
            src_buffer,
            None,
            byref(num_buffers)
        )

        return num_buffers.value


